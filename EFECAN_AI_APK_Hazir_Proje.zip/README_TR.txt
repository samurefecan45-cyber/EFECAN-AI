EFECAN AI - Android başlangıç projesi

Bu klasör Android Studio ile açılabilen yerel Android uygulama projesidir.

Açma:
1. Bilgisayara Android Studio kur.
2. Android Studio > Open ile bu klasörü seç.
3. Gradle eşitlemesi tamamlanınca bir Android cihaz/emülatör seç.
4. Run düğmesine bas.

ÖNEMLİ:
Bu ilk sürüm Jarvis tarzı sohbet arayüzüdür. Gerçek yapay zekâ yanıtları henüz bağlı değildir.
Gerçek AI için bir sunucu/API bağlantısı gerekir. Gizli API anahtarını Android uygulamasının içine koyma;
anahtar güvenli bir sunucuda tutulmalıdır. Bu proje doğrudan APK değildir.
