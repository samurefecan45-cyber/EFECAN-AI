package com.efecanai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF080D1A)
private val Panel = Color(0xFF111B2E)
private val Cyan = Color(0xFF42D9F5)
private val Purple = Color(0xFF806BFF)

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EfecanAIApp() }
    }
}

@Composable
fun EfecanAIApp() {
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf(ChatMessage("Merhaba! Ben EFECAN AI. Sana nasıl yardımcı olabilirim?", false)))
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Cyan, onBackground = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF101D38), Navy, Color(0xFF090B16)))
            ).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp, bottom = 18.dp)) {
                Box(
                    Modifier.size(48.dp).background(Brush.linearGradient(listOf(Cyan, Purple)), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Navy, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("EFECAN AI", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("KİŞİSEL YAPAY ZEKÂ ASİSTANIN", color = Cyan, fontSize = 9.sp, letterSpacing = 1.4.sp)
                }
                Spacer(Modifier.weight(1f))
                Surface(color = Color(0xFF153A3B), shape = RoundedCornerShape(20.dp)) {
                    Text("● HAZIR", color = Color(0xFF6FFFC2), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                }
            }

            Surface(
                color = Color(0x221C9CB7), shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("SİSTEM ÇEVRİMİÇİ", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("Bugün ne yapıyoruz?", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("Sorunu yaz; birlikte çözelim.", color = Color(0xFFB6C5D8), fontSize = 12.sp)
                }
            }

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (msg.fromUser) Color(0xFF253B63) else Panel,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(msg.text, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(13.dp))
                        }
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(28.dp)).padding(horizontal = 15.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text("EFECAN AI'ya mesaj yaz...", color = Color(0xFF8493A8), fontSize = 14.sp)
                        inner()
                    }
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = {
                    val question = input.trim()
                    if (question.isNotEmpty()) {
                        messages = messages + ChatMessage(question, true)
                        messages = messages + ChatMessage(
                            "Mesajını aldım! Şu an bu başlangıç sürümünde gerçek yapay zekâ bağlantısı henüz kurulmadı. Gerçek cevaplar için güvenli bir yapay zekâ sunucusu bağlanması gerekiyor.",
                            false
                        )
                        input = ""
                    }
                }) {
                    Icon(Icons.Default.Send, contentDescription = "Gönder", tint = Cyan)
                }
            }
            Text("EFECAN AI • İlk arayüz sürümü", color = Color(0xFF64748B), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp))
        }
    }
}
